#!/bin/bash

chmod +x gradlew

./gradlew build

java -jar build/libs/ACO.jar 0.4 1.0 0.65 100
java -jar build/libs/ACO.jar 0.4 1.0 0.65 100
java -jar build/libs/ACO.jar 0.4 1.0 0.65 100
java -jar build/libs/ACO.jar 0.4 1.0 0.65 100
java -jar build/libs/ACO.jar 0.4 1.0 0.65 100
echo "*************************************************" >> output.txt
echo "*************************************************" >> output.txt

java -jar build/libs/ACO.jar 1.0 0.4 0.65 100
java -jar build/libs/ACO.jar 1.0 0.4 0.65 100
java -jar build/libs/ACO.jar 1.0 0.4 0.65 100
java -jar build/libs/ACO.jar 1.0 0.4 0.65 100
java -jar build/libs/ACO.jar 1.0 0.4 0.65 100
echo "*************************************************" >> output.txt
echo "*************************************************" >> output.txt

java -jar build/libs/ACO.jar 1.0 1.0 0.65 100
java -jar build/libs/ACO.jar 1.0 1.0 0.65 100
java -jar build/libs/ACO.jar 1.0 1.0 0.65 100
java -jar build/libs/ACO.jar 1.0 1.0 0.65 100
java -jar build/libs/ACO.jar 1.0 1.0 0.65 100
echo "*************************************************" >> output.txt
echo "*************************************************" >> output.txt

java -jar build/libs/ACO.jar 1.0 1.0 0.4 100
java -jar build/libs/ACO.jar 1.0 1.0 0.4 100
java -jar build/libs/ACO.jar 1.0 1.0 0.4 100
java -jar build/libs/ACO.jar 1.0 1.0 0.4 100
java -jar build/libs/ACO.jar 1.0 1.0 0.4 100
echo "*************************************************" >> output.txt
echo "*************************************************" >> output.txt

java -jar build/libs/ACO.jar 1.0 1.0 0.95 100
java -jar build/libs/ACO.jar 1.0 1.0 0.95 100
java -jar build/libs/ACO.jar 1.0 1.0 0.95 100
java -jar build/libs/ACO.jar 1.0 1.0 0.95 100
java -jar build/libs/ACO.jar 1.0 1.0 0.95 100

echo "*************************************************" >> output.txt
echo "*************************************************" >> output.txt
